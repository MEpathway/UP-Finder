function resultString = geneCellToString(gene)
resultString = '';
sizeOfCell = size(gene);
totalNumOfCell = sizeOfCell(1)*sizeOfCell(2);
if totalNumOfCell == 0
    resultString = 'NULL';
%{
elseif totalNumOfCell == 1
    resultString = gene{1,1};
%}
else 
    for i = 1:sizeOfCell(1)
        for j = 1:sizeOfCell(2)
            if iscell(gene{i,j})
                insideCell = gene{i,j};
                sizeOfInsideCell = size(insideCell);
                for p=1:sizeOfInsideCell(1)
                    for q = 1:sizeOfInsideCell(2)
                        subString = insideCell{p,q};
                        resultString = strcat(resultString,subString,','); 
                    end
                end
            else
                subString = gene{i,j};
                resultString = strcat(resultString,subString,',');
            end
            
        end
    end
end
