function varargout = software_gui(varargin)
% SOFTWARE_GUI MATLAB code for software_gui.fig
%      SOFTWARE_GUI, by itself, creates a new SOFTWARE_GUI or raises the existing
%      singleton*.
%
%      H = SOFTWARE_GUI returns the handle to a new SOFTWARE_GUI or the handle to
%      the existing singleton*.
%
%      SOFTWARE_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SOFTWARE_GUI.M with the given input arguments.
%
%      SOFTWARE_GUI('Property','Value',...) creates a new SOFTWARE_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before software_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to software_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help software_gui

% Last Modified by GUIDE v2.5 23-Oct-2014 17:10:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @software_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @software_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before software_gui is made visible.
function software_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to software_gui (see VARARGIN)

% Choose default command line output for software_gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes software_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = software_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

initCobraToolbox;
[filename pathname] = uigetfile({'*.xml'},'File Selector');
fullpathname = strcat(pathname, filename);
set(handles.text4, 'String', filename);
set(handles.text1, 'String', fullpathname);
handles.originModel = readCbModel(filename);
guidata(hObject,handles);
%set the objective popup menu
%%%%  set(handles.popupmenu1, 'String',handles.originModel.mets);
%1. remove the [e] ub==in mets
t=1;
for i=1:length(handles.originModel.mets)
    if(isempty(findstr('[e]',char(handles.originModel.mets(i)))))
        objectiveList(t)= handles.originModel.mets(i);
        t=t+1;
    end
end
x = strmatch('EX',handles.originModel.rxns);
for i = 1:length(x)
    popupString(i) = handles.originModel.rxns(x(i));
end

set(handles.popupmenu1, 'String',objectiveList);
set(handles.popupmenu4,'String',popupString);
set(handles.popupmenu7,'String',popupString);
set(handles.popupmenu10,'String',popupString);
set(handles.popupmenu13,'String',popupString);
set(handles.popupmenu16,'String',popupString);
n = 1;
for i = 1:length(handles.originModel.rxns)
    a = strfind(handles.originModel.rxns,'biomass');
    b = strfind(handles.originModel.rxns,'Biomass');
end

for i = 1:length(handles.originModel.rxns)
    if (~isempty(a{i,1}))
         popupGrowth(n) = handles.originModel.rxns(i);
         n = n+1;  
    end   
end
for i = 1:length(handles.originModel.rxns)
    if(~isempty(b{i,1}))
        popupGrowth(n) = handles.originModel.rxns(i);
        n = n+1;
    end
end
%set the state of condition's button to all false
handles.condition1set = false;
handles.lb1set=false;
handles.ub1set=false;
handles.condition2set = false;
handles.lb2set=false;
handles.ub2set=false;
handles.condition3set = false;
handles.lb3set=false;
handles.ub3set=false;
handles.condition4set = false;
handles.lb4set=false;
handles.ub4set=false;
handles.condition5set = false;
handles.lb5set=false;
handles.ub5set=false;
handles.growthset=false;
handles.objectiveset = false;
set(handles.popupmenu19,'String',popupGrowth);
guidata(hObject,handles);


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
%%%%%%   objective menu %%%%%%%
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
contents = get(handles.popupmenu1,'String');
handles.userChooseObjective = contents{get(handles.popupmenu1,'Value')};
handles.objectiveset=true;
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clearString=[];
set(handles.listbox1,'String', clearString);
guidata(hObject,handles);

contents = get(handles.popupmenu2,'String');
popupmenu4value = contents{get(handles.popupmenu2,'Value')};
switch popupmenu4value
    case 'FBA'
        solution = optimizeCbModel(handles.originModel);
        set(handles.listbox1,'String',solution.f);
    case 'UPA'
        handles.model = handles.originModel;
        if handles.condition1set && handles.lb1set
            
            handles.model = changeRxnBounds(handles.model,handles.condition1,handles.lb1,'l');
        end
        if handles.condition1set && handles.ub1set
            
            handles.model = changeRxnBounds(handles.model,handles.condition1,handles.ub1,'u');
        end
        
        if handles.condition2set && handles.lb2set
            
            handles.model = changeRxnBounds(handles.model,handles.condition2,handles.lb2,'l');
        end
        if handles.condition2set && handles.ub2set
            
            handles.model = changeRxnBounds(handles.model,handles.condition2,handles.ub2,'u');
        end
        
        if handles.condition3set && handles.lb3set
            
            handles.model = changeRxnBounds(handles.model,handles.condition3,handles.lb3,'l');
        end
        if handles.condition3set && handles.ub3set
            
            handles.model = changeRxnBounds(handles.model,handles.condition3,handles.ub3,'u');
        end
        
        if handles.condition4set && handles.lb4set
            handles.model = changeRxnBounds(handles.model,handles.condition4,handles.lb4,'l');
        end
        if handles.condition4set && handles.ub4set
            handles.model = changeRxnBounds(handles.model,handles.condition4,handles.ub4,'u');
        end
        
        if handles.condition5set && handles.lb5set
            handles.model = changeRxnBounds(handles.model,handles.condition5,handles.lb5,'l');
        end
        if handles.condition5set && handles.ub5set
            handles.model = changeRxnBounds(handles.model,handles.condition5,handles.ub5,'u');
        end
        if handles.growthset
            
            handles.model = changeObjective(handles.model,handles.growthString);
        end
        % there are 2 cases:        
        if handles.objectiveset                 
           if(~isempty(strfind(handles.userChooseObjective,'ACP[c]')))
                DMObjective = strcat('DM_',handles.userChooseObjective); % combine DM_ with userChooseObjective
                Formular = strcat(handles.userChooseObjective,' -> ACP[c]');
                handles.modelAddOne = addReaction(handles.model,DMObjective,Formular);
                b = DMObjective;
           %small case 2: there are 'coa' found in the objective 
           elseif(~(isempty(strfind(handles.userChooseObjective,'coa[c]'))))
                DMObjective = strcat('DM_',handles.userChooseObjective);
                Formular = strcat(handles.userChooseObjective,' -> coa[c]');
                handles.modelAddOne = addReaction(handles.model,DMObjective,Formular);
                b = DMObjective;
                % otherwise: not ACP[c], and not coa[c]    
            else
                [handles.modelAddOne,b] = addDemandReaction(handles.model,handles.userChooseObjective);
            end
           try
                handles.modelUser = changeObjective(handles.modelAddOne,b);
            catch errorObj
                errordlg(getReport(errorObj,'extended','hyperlinks','off'),'Error');
            end
        handles.rxnID = findRxnIDs(handles.modelAddOne,b); 
        
        end
        %solution1 is the solution of the add one rxns's model  
        % if solution1.f isempty, end this run.
        solution1 = optimizeCbModel(handles.modelAddOne); 
        
        %solution_user is the solution of the model that after user choose
        %targeted product, modelUser is get from changeObjective
        %modelAddOne
        solution_user = optimizeCbModel(handles.modelUser);
        rxnsNum = length(handles.modelAddOne.rxns);
        diff = zeros(rxnsNum,1);
        ratioAndID = zeros(rxnsNum,2);        
        if(numel(solution_user.x)==0 || solution_user.f==0||solution1.f==0)
            output='No valid result(s), please re-set the parameters (either Objectives or Conditions)';
            set(handles.listbox1,'String', output);
        else
            for i = 1: rxnsNum      
                if isempty(solution_user.x(i))
            	solution_user.x(i) = 0;
                end
                diff(i) = solution_user.x(i) - solution1.x(i);
                if solution1.x(i)==0
                    ratioAndID(i,1) = 0;
                else
                    ratioAndID (i,1) = diff(i) / solution1.x(i); 
                end
                ratioAndID(i,2) = i; 
            end
        
        %add one step to delete the inf,-inf,NaN ratio value
        legalratioNum = 0;
        for i = 1:rxnsNum-1
            if ratioAndID(i,1)>0 
                legalratioNum = legalratioNum+1;
            end
        end
        legal_ratioAndID = zeros(legalratioNum,2);
        t = 1;
        for i = 1:rxnsNum-1
            if ratioAndID(i,1)>0
                legal_ratioAndID(t,1) = ratioAndID(i,1);
                legal_ratioAndID(t,2) = ratioAndID(i,2);
                t = t+1;
            end
        end
        % if the legalratioNum is 0,
        % then print the error message in the out put listbox
        if legalratioNum==0
            output = 'No valid result(s), please re-set the parameters (either Objectives or Conditions)';
            set(handles.listbox1,'String', output);
        else
        % get the yield array
            yieldRatioAndID{legalratioNum,3} = []; 
            % yieldRatioAndID contains: {yield,ratio,rxnID}
            for i = 1: legalratioNum
                model_test = changeRxnBounds(handles.modelAddOne,handles.modelAddOne.rxns(legal_ratioAndID(i,2)),solution_user.x(legal_ratioAndID(i,2)),'b');
                sol_test = optimizeCbModel(model_test,'max');
                if isempty(sol_test.x(handles.rxnID))
                    yieldRatioAndID{i,1} = 0 ;
                    yieldRatioAndID{i,2} = legal_ratioAndID(i,1);
                    yieldRatioAndID{i,3} = legal_ratioAndID(i,2);
                else
                    yieldRatioAndID{i,1} = sol_test.x(handles.rxnID);
                    yieldRatioAndID{i,2} = legal_ratioAndID(i,1);
                    yieldRatioAndID{i,3} = legal_ratioAndID(i,2);             
                end
            end
        end
        
        % calculate solution num
        numSol = 0;
        for i = 1: legalratioNum
            if yieldRatioAndID{i,1} > 0 && legal_ratioAndID(i,2)~=0
                numSol = numSol + 1;
            end
        end
        % numSol requires to be greater than 0
        if numSol==0
            output = 'No valid result(s), please re-set the parameters (either Objectives or Conditions)';
            set(handles.listbox1,'String', output);
        else
        %get the result: yield > 0 && the id is legal. 
            result_yieldRatioAndID{numSol,6} = []; 
            %{1} is NO. ; {2} is rxns; % {3} is gene; {4} is yield; {5} is ratio; {6} is formula       
            t=1;
            for i=1:legalratioNum
                id = legal_ratioAndID(i,2);
                if yieldRatioAndID{i,1} > 0 && legal_ratioAndID(i,2)~=0
                    result_yieldRatioAndID{t,1} = t ; % {1} is NO.
                    result_yieldRatioAndID{t,2} = id; %{2} is ID
               % get gene based on the rxns ID              
                    gene = findGenesFromRxns(handles.modelUser,handles.modelUser.rxns(id)) ;
                    result_yieldRatioAndID{t,3} = geneCellToString(gene); %Gene
%               
                    result_yieldRatioAndID{t,4} = yieldRatioAndID{i,1}; % yield
                    result_yieldRatioAndID{t,5} = yieldRatioAndID{i,2}; % ratio
               % get the formula based on the rxns ID
                    formula = printRxnFormula(handles.modelUser,handles.modelUser.rxns(id));               
                    result_yieldRatioAndID{t,6} = formulaCellToString(formula); %formula
                    t=t+1;
                end
            end
        end
        handles.solutionNum = numSol;
        % get how much user has chosen

        if handles.solutionNum == 0
            output = 'No valid result(s), please re-set the parameters (either Objectives or Conditions)';
            set(handles.listbox1,'String', output);
        else
            handles.outputNum = handles.solutionNum;
            guidata(hObject,handles);
    
            % sort the result by ratio, which is put in 5th column
            sortedYieldAndRatio = sortrows(result_yieldRatioAndID,5);
            

            %flip the sorted largest is at the end, so put them at the
            %front! flip method can only flip one line, so converse the
            %cell first and converse back the cell array.
            sortedYieldAndRatio = sortedYieldAndRatio';
            sortedYieldAndRatio = fliplr(sortedYieldAndRatio);
            sortedYieldAndRatio = sortedYieldAndRatio';
            
            t = 1;
            for i = 1:handles.solutionNum
                id = sortedYieldAndRatio{i,2};
                if id~=0
                    handles.result{t,1} = t;
                    rxnsName = handles.modelUser.rxns(id);
                    handles.result{t,2} = rxnsName{1}; % reaction name
                    handles.result{t,3} = sortedYieldAndRatio{i,3};   % gene name
                    handles.result{t,4} = sortedYieldAndRatio{i,4};   % yield
                    handles.result{t,5} = sortedYieldAndRatio{i,5};   % ratio
                    handles.result{t,6} = sortedYieldAndRatio{i,6};   % formula
                    t=t+1;
                end
            end
            guidata(hObject,handles);
            % copy the outputNum rows into output array
            output = handles.result(1:handles.outputNum,1:6)
        
            % set output into the table
            set(handles.uitable1,'data',output);
        end
        end  
        
end
     
%guidata(hObject,handles);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3

%contents = cellstr(get(handles.popupmenu3,'String'));
%handles.userChooseTargetNum = contents{get(handles.popupmenu3,'Value')};
handles.userChooseTargetNum = get(handles.popupmenu3,'Value');
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu4.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu4
contents = cellstr(get(handles.popupmenu4,'String'));
handles.condition1 = contents{get(handles.popupmenu4,'Value')};
handles.condition1set = true;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5
contents = cellstr(get(handles.popupmenu5,'String'));
lb1String = contents{get(handles.popupmenu5,'Value')};
if isequal(lb1String,'Default')
    lb1ID = findRxnIDs(handles.originModel,handles.condition1);
    handles.lb1 = handles.originModel.lb(lb1ID);
    handles.lb1set=true;
else
    handles.lb1 = str2double(lb1String);
    handles.lb1set=true;
end
guidata(hObject,handles);



% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu6.
function popupmenu6_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu6 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu6


% --- Executes during object creation, after setting all properties.
function popupmenu6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu7.
function popupmenu7_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu7 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu7
contents = cellstr(get(handles.popupmenu7,'String'));
handles.condition2 = contents{get(handles.popupmenu7,'Value')};
handles.condition2set=true;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu8.
function popupmenu8_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu8 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu8


% --- Executes during object creation, after setting all properties.
function popupmenu8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu9.
function popupmenu9_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu9 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu9


% --- Executes during object creation, after setting all properties.
function popupmenu9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu10.
function popupmenu10_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu10 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu10
contents = cellstr(get(handles.popupmenu10,'String'));
handles.condition3 = contents{get(handles.popupmenu10,'Value')};
handles.condition3set=true;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu11.
function popupmenu11_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu11 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu11


% --- Executes during object creation, after setting all properties.
function popupmenu11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu12.
function popupmenu12_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu12 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu12


% --- Executes during object creation, after setting all properties.
function popupmenu12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu13.
function popupmenu13_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu13 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu13
contents = cellstr(get(handles.popupmenu13,'String'));
handles.condition4 = contents{get(handles.popupmenu13,'Value')};
handles.condition4set=true;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu14.
function popupmenu14_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu14 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu14


% --- Executes during object creation, after setting all properties.
function popupmenu14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu15.
function popupmenu15_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu15 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu15


% --- Executes during object creation, after setting all properties.
function popupmenu15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu16.
function popupmenu16_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu16 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu16
contents = cellstr(get(handles.popupmenu16,'String'));
handles.condition5 = contents{get(handles.popupmenu16,'Value')};
handles.condition5set=true;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu17.
function popupmenu17_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu17 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu17


% --- Executes during object creation, after setting all properties.
function popupmenu17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu18.
function popupmenu18_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu18 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu18


% --- Executes during object creation, after setting all properties.
function popupmenu18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu19.
function popupmenu19_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu19 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu19
contents = cellstr(get(handles.popupmenu19,'String'));
handles.growthString = contents{get(handles.popupmenu19,'Value')};
handles.growthset = true;
guidata(hObject,handles);





% --- Executes during object creation, after setting all properties.
function popupmenu19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu20.
function popupmenu20_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu20 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu20
contents = cellstr(get(handles.popupmenu20,'String'));
ub1String = contents{get(handles.popupmenu20,'Value')};
if isequal(ub1String,'Default')
    ub1ID = findRxnIDs(handles.originModel,handles.condition1);
    handles.ub1 = handles.originModel.ub(ub1ID);
    handles.ub1set=true;
else
    handles.ub1 = str2double(ub1String);
    handles.ub1set=true;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu21.
function popupmenu21_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu21 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu21
contents = cellstr(get(handles.popupmenu21,'String'));
lb2String = contents{get(handles.popupmenu21,'Value')};
if isequal(lb2String,'Default')
    lb2ID = findRxnIDs(handles.originModel,handles.condition2);
    handles.lb2 = handles.originModel.lb(lb2ID);
    handles.lb2set=true;
else
    handles.lb2 = str2double(lb2String);
    handles.lb2set=true;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu22.
function popupmenu22_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu22 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu22
contents = cellstr(get(handles.popupmenu22,'String'));
ub2String = contents{get(handles.popupmenu22,'Value')};
if isequal(ub2String,'Default')
    ub2ID = findRxnIDs(handles.originModel,handles.condition2);
    handles.ub2 = handles.originModel.ub(ub2ID);
    handles.ub2set=true;
else
    handles.ub2 = str2double(ub2String);
    handles.ub2set=true;
    %handles.model = changeRxnBounds(handles.model,handles.condition2,handles.ub2,'u');
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu23.
function popupmenu23_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu23 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu23
contents = cellstr(get(handles.popupmenu23,'String'));
ub3String = contents{get(handles.popupmenu23,'Value')};
if isequal(ub3String,'Default')
    ub3ID = findRxnIDs(handles.originModel,handles.condition3);
    handles.ub3 = handles.originModel.ub(ub3ID);
    handles.ub3set=true;
else
    handles.ub3 = str2double(ub3String);
    handles.ub4set=true;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu24.
function popupmenu24_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu24 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu24
contents = cellstr(get(handles.popupmenu24,'String'));
lb3String = contents{get(handles.popupmenu24,'Value')};
if isequal(lb3String,'Default')
    lb3ID = findRxnIDs(handles.originModel,handles.condition3);
    handles.lb3 = handles.originModel.lb(lb3ID);
    handles.lb3set=true;
else
    handles.lb3 = str2double(lb3String);
    handles.lb3set=true;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu25.
function popupmenu25_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu25 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu25
contents = cellstr(get(handles.popupmenu25,'String'));
ub4String = contents{get(handles.popupmenu25,'Value')};
if isequal(ub4String,'Default')
    ub4ID = findRxnIDs(handles.originModel,handles.condition4);
    handles.ub4 = handles.originModel.ub(ub4ID);
    handles.ub4set=true;
else
    handles.ub4 = str2double(ub4String);
    handles.ub4set=true;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu26.
function popupmenu26_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu26 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu26
contents = cellstr(get(handles.popupmenu26,'String'));
lb4String = contents{get(handles.popupmenu26,'Value')};
if isequal(lb4String,'Default')
    lb4ID = findRxnIDs(handles.originModel,handles.condition4);
    handles.lb4 = handles.originModel.lb(lb4ID);
    handles.lb4set=true;
  
else
    handles.lb4 = str2double(lb4String);
    handles.lb4set=true;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu27.
function popupmenu27_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu27 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu27
contents = cellstr(get(handles.popupmenu27,'String'));
ub5String = contents{get(handles.popupmenu27,'Value')};
if isequal(ub5String,'Default')
    ub5ID = findRxnIDs(handles.originModel,handles.condition5);
    handles.ub5 = handles.originModel.ub(ub5ID);
    handles.ub5set=true;
else
    handles.ub5 = str2double(ub5String);
        handles.ub5set=true;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu28.
function popupmenu28_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu28 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu28
contents = cellstr(get(handles.popupmenu28,'String'));
lb5String = contents{get(handles.popupmenu28,'Value')};
if isequal(lb5String,'Default')
    lb5ID = findRxnIDs(handles.originModel,handles.condition5);
    handles.lb5 = handles.originModel.lb(lb5ID);
    handles.lb5set=true;
else
    handles.lb5 = str2double(lb5String);
    handles.lb5set=true;
end
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popupmenu28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
