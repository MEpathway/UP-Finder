function resultString = formulaCellToString(formulaCell)
sizeOfCell = size(formulaCell); %return row col
totalNumOfCell = sizeOfCell(1)*sizeOfCell(2);
if totalNumOfCell == 0
    resultString = 'NULL';
elseif totalNumOfCell ==1
    resultString = formulaCell{1};
else
    for i = 1:sizeOfCell(1)
        for j = 1:sizeOfCell(2)
            insideCell = formulaCell{i,j};
            sizeOfInsideCell = size(insideCell);
            for p = 1: sizeOfInsideCell(1)
                for q = 1:sizeOfInsideCell(2)
                    resultString = strcat(resultString,',',insideCell(p,q));
                end
            end
                
        end
    end
end
end
% combine strings: s = strcat(s1,...,sN);

%{
function testFormulaToString
result_yieldRatioAndID{numSol,6} = [];
        t=1;
for x=1:legalratioNum
            id = legal_ratioAndID(x,2);
if yieldRatioAndID{x,1} > 0 && legal_ratioAndID(x,2)~=0
   result_yieldRatioAndID{t,1} = t ; % {1} is NO.
   result_yieldRatioAndID{t,2} = id;
   testGene= findGenesFromRxns(modelUser,modelUser.rxns(id));
   result_yieldRatioAndID{t,3} =geneCellToString(testGene);
   result_yieldRatioAndID{t,4} = yieldRatioAndID{x,1}; % yield
   result_yieldRatioAndID{t,5} = yieldRatioAndID{x,2};
   formula = printRxnFormula(modelUser,modelUser.rxns(id));
   result_yieldRatioAndID{t,6}=formulaCellToString(formula);
   t=t+1;
   end
  end
 end
%}


